JM Ventas Informática — Sitio web estático

Instrucciones para publicar en GitHub Pages:

1. Asegúrate de que `index.html` esté en la raíz del repositorio y que las carpetas `assets/` e `imagenes/` estén presentes.
2. Inicializa el repositorio y sube al remoto:

   git init
   git add .
   git commit -m "Initial commit: sitio JM Ventas Informática"
   git branch -M main
   git remote add origin https://github.com/USERNAME/REPO.git
   git push -u origin main

3. En GitHub: ve al repositorio → Settings → Pages → selecciona la rama `main` y la carpeta `/ (root)` → Save. La URL será `https://USERNAME.github.io/REPO/`.

Notas:
- Si quieres, puedo generar un zip listo para subir a Netlify o crear comandos listos para ejecutar en tu terminal para crear el repo con GitHub CLI (`gh repo create`).
- He copiado el archivo original a `index.html` y mantuve `assets/hero.jpg` local.